package com.example.whattodo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerViewAccessibilityDelegate;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;

import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements RecyclerViewClickInterface {

    RecyclerView recyclerView;
    RecyclerView.Adapter adapter;
    RecyclerView.LayoutManager manager;
    Vibrator vibrator;
    Button clear,add,stats,addTask,yes,no,yesAll,noAll,yesTask,noTask,back;
    TextView date,completed,pending;
    EditText time,task;
    Dialog dialog,delDialog,allDialog,taskDialog,statDialog;
    DatePickerDialog.OnDateSetListener listener;
    String dayOfWeek;
    int selection;
    SharedPreferences prefs;
    SharedPreferences.Editor editor;
    String count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //dialog box for adding/editing tasks
        dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.add_dialog);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        //dialog box for deleting tasks on long press
        delDialog = new Dialog(MainActivity.this);
        delDialog.setContentView(R.layout.delete_item);
        delDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        //dialog box for deleting all tasks
        allDialog = new Dialog(MainActivity.this);
        allDialog.setContentView(R.layout.delete_all);
        allDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        //dialog box for verifying task completion
        taskDialog = new Dialog(MainActivity.this);
        taskDialog.setContentView(R.layout.task_complete);
        taskDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        //dialog box for displaying stats
        statDialog = new Dialog(MainActivity.this);
        statDialog.setContentView(R.layout.stats_page);
        statDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);

        //importing variables from all the layouts (till line 99)
        clear = findViewById(R.id.clearView);
        add = findViewById(R.id.addView);
        stats = findViewById(R.id.statsView);

        addTask = dialog.findViewById(R.id.addTaskButton);

        yes = delDialog.findViewById(R.id.yesButton);
        no = delDialog.findViewById(R.id.noButton);

        yesAll = allDialog.findViewById(R.id.yesButton);
        noAll = allDialog.findViewById(R.id.noButton);

        yesTask = taskDialog.findViewById(R.id.yesButton);
        noTask = taskDialog.findViewById(R.id.noButton);

        date = dialog.findViewById(R.id.dateText);
        task = dialog.findViewById(R.id.taskNameText);
        time = dialog.findViewById(R.id.timeText);

        completed = statDialog.findViewById(R.id.completedText);
        pending = statDialog.findViewById(R.id.pendingText);
        back = statDialog.findViewById(R.id.exitButton);

        date.setClickable(true);

        //importing the object ArrayList data stored in SharedPreferences
        ArrayList<RecyclerItem> note = PreConfig.readListFromPref(this);

        if(note == null){
            note = new ArrayList<RecyclerItem>();
        }

        //setting adapter and layout manager for the recycler view and binding it to the RecyclerItem ArrayList
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        manager = new LinearLayoutManager(this);
        adapter = new RecyclerAdapter(note,this);

        prefs = this.getSharedPreferences(String.valueOf(getApplicationContext()), Context.MODE_PRIVATE);
        editor = prefs.edit();

        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                date.setText("");
                task.getText().clear();
                time.getText().clear();
                addTask.setText("Add task");
                dialog.show();
            }
        });

        //Setting and obtaining date from user while adding task
        Calendar cal = Calendar.getInstance();
        final int year = cal.get(Calendar.YEAR);
        final int month = cal.get(Calendar.MONTH);
        final int day = cal.get(Calendar.DAY_OF_MONTH);

        date.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                DatePickerDialog datePicker = new DatePickerDialog(MainActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,listener,year,month,day);
                datePicker.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePicker.show();
            }
        });

        //receiving date input from text view
        listener  = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int dayOfMonth) {
                Calendar cal = Calendar.getInstance();
                cal.set(year,month,dayOfMonth);
                dayOfWeek = cal.getTime().toString().split(" ")[0];
                month = month+1;
                if(month<10){
                    date.setText(String.valueOf(dayOfMonth) + "/" + "0" + String.valueOf(month) + "/" + String.valueOf(year));
                }else{
                date.setText(String.valueOf(dayOfMonth) + "/" + String.valueOf(month) + "/" + String.valueOf(year));}
            }
        };

        ArrayList<RecyclerItem> finalNote = note;

        addTask.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                //checking if any item is empty
                if(date.getText().toString().isEmpty() || time.getText().toString().isEmpty() || task.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"All fields are required",Toast.LENGTH_SHORT).show();

                }
                else{
                String[] timeArr = time.getText().toString().split(":");
                //checking if time format is valid
                if(Integer.valueOf(timeArr[0])<25 && Integer.valueOf(timeArr[1])<60){
                    String dateEntry = date.getText().toString();
                    String taskEntry = task.getText().toString();
                    String timeEntry = time.getText().toString();

                 //adding task to the database
                    finalNote.add(new RecyclerItem(dateEntry,dayOfWeek,timeEntry,taskEntry));
                    recyclerView.setLayoutManager(manager);
                    recyclerView.setAdapter(adapter);
                    PreConfig.writeListInPref(getApplicationContext(), finalNote);
                    date.setText("");
                    task.getText().clear();
                    time.getText().clear();
                    dialog.cancel();
                }else{
                    time.getText().clear();
                    time.setError("Invalid Input");
                }
                }
            }
        });

        //all yes and no type buttons are similar, yes does the task and no cancels it
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delDialog.cancel();
                finalNote.remove(selection);
                recyclerView.setLayoutManager(manager);
                recyclerView.setAdapter(adapter);
                PreConfig.writeListInPref(getApplicationContext(), finalNote);
                Toast.makeText(getApplicationContext(),"Task Deleted",Toast.LENGTH_SHORT).show();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                delDialog.cancel();
            }
        });

        clear.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                allDialog.show();
            }
        });

        yesAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                allDialog.cancel();
                finalNote.clear();
                recyclerView.setLayoutManager(manager);
                recyclerView.setAdapter(adapter);
                PreConfig.writeListInPref(getApplicationContext(), finalNote);
                Toast.makeText(getApplicationContext(),"All Tasks Deleted",Toast.LENGTH_SHORT).show();
            }
        });

        noAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                allDialog.cancel();
            }
        });

        noTask.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                taskDialog.cancel();
            }
        });

        //completes task by removing it from list and adds 1 to completed variable in database
        yesTask.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                taskDialog.cancel();
                finalNote.remove(selection);
                recyclerView.setLayoutManager(manager);
                recyclerView.setAdapter(adapter);
                PreConfig.writeListInPref(getApplicationContext(), finalNote);
                Toast.makeText(getApplicationContext(),"Task Completed",Toast.LENGTH_SHORT).show();
                count = prefs.getString("Count","");
                Integer val;

                try {
                    val = Integer.parseInt(count);

                } catch (NumberFormatException e) {
                    val = 0;
                }

                val = val + 1;

                count = String.valueOf(val);
                editor.putString("Count",count);
                editor.commit();
            }
        });

        //view stats (tasks pending and completed)
        stats.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                count = prefs.getString("Count","");
                try{
                    Integer val = Integer.parseInt(count);
                }catch (NumberFormatException e){
                    count = "0";
                }

                statDialog.show();
                completed.setText("Tasks Completed : " + count);
                pending.setText("Tasks Pending      : " + String.valueOf(finalNote.size()));

            }
        });

        back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                statDialog.cancel();
            }
        });

    }

    //opens option to complete task
    @Override
    public void onItemClick(int position) {
        taskDialog.show();
    }

    //opens option to delete task
    @Override
    public void onItemLongClick(int position) {
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        vibrator.vibrate(1000);
        selection = position;
        delDialog.show();
    }

    //opens option to edit the task (some code might look repeated but it was inevitable)
    @Override
    public void onImgClick(int position) {

        dialog.show();
        addTask.setText("Edit");

        ArrayList<RecyclerItem> note = PreConfig.readListFromPref(this);

        if(note == null){
            note = new ArrayList<RecyclerItem>();
        }

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        manager = new LinearLayoutManager(this);
        adapter = new RecyclerAdapter(note,this);

        recyclerView.setLayoutManager(manager);
        recyclerView.setAdapter(adapter);

        time.setText(note.get(position).getTime());
        date.setText(note.get(position).getDate());
        task.setText(note.get(position).getTask());

        ArrayList<RecyclerItem> finalNote = note;
        addTask.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {

                if(date.getText().toString().isEmpty() || time.getText().toString().isEmpty() || task.getText().toString().isEmpty())
                {
                    Toast.makeText(getApplicationContext(),"All fields are required",Toast.LENGTH_SHORT).show();

                }
                else{
                    String[] timeArr = time.getText().toString().split(":");
                    if(Integer.valueOf(timeArr[0])<25 && Integer.valueOf(timeArr[1])<60){
                        String dateEntry = date.getText().toString();
                        String taskEntry = task.getText().toString();
                        String timeEntry = time.getText().toString();

                        finalNote.set(position,new RecyclerItem(dateEntry,dayOfWeek,timeEntry,taskEntry));
                        recyclerView.setLayoutManager(manager);
                        recyclerView.setAdapter(adapter);
                        PreConfig.writeListInPref(getApplicationContext(), finalNote);
                        date.setText("");
                        task.getText().clear();
                        time.getText().clear();
                        dialog.cancel();
                    }else{
                        time.getText().clear();
                        time.setError("Invalid Input");
                    }
                }
            }
        });
    }
}

//end of code
//the layouts for various tasks like add,remove,etc. are stored in R.layout directory