package com.example.whattodo;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.RecyclerHolder> {
    private ArrayList<RecyclerItem> newRecyclerList;
    private static RecyclerViewClickInterface clickInterface;

    public static class RecyclerHolder extends RecyclerView.ViewHolder {
        public TextView dateText;
        public TextView dayText;
        public TextView timeText;
        public TextView taskText;
        public ImageView editImg;

        public RecyclerHolder(@NonNull View itemView) {
            super(itemView);
            dateText = itemView.findViewById(R.id.dateText);
            dayText = itemView.findViewById(R.id.dayText);
            timeText = itemView.findViewById(R.id.timeText);
            taskText = itemView.findViewById(R.id.taskText);
            editImg = itemView.findViewById(R.id.editImg);

            editImg.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    clickInterface.onImgClick(getAdapterPosition());
                }
            });

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    clickInterface.onItemClick(getAdapterPosition());
                }
            });

            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    clickInterface.onItemLongClick(getAdapterPosition());
                    return true;
                }
            });

        }
    }

    public RecyclerAdapter(ArrayList<RecyclerItem> recyclerList,RecyclerViewClickInterface recyclerViewClickInterface){
        newRecyclerList = recyclerList;
        clickInterface = recyclerViewClickInterface;

    }

    @NonNull
    @Override
    public RecyclerHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_items, parent,false);
        RecyclerHolder rh = new RecyclerHolder(v);
        return rh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerHolder holder, int position) {
        RecyclerItem currentItem = newRecyclerList.get(position);
        holder.dateText.setText(currentItem.getDate());
        holder.dayText.setText(currentItem.getDay());
        holder.timeText.setText(currentItem.getTime());
        holder.taskText.setText(currentItem.getTask());
    }

    @Override
    public int getItemCount() {
        return newRecyclerList.size();
    }
}
