package com.example.whattodo;

public class RecyclerItem {
    private String date;
    private String day;
    private String time;
    private String task;

    public RecyclerItem(String date,String day,String time,String task){
        this.date = date;
        this.day = day;
        this.time = time;
        this.task = task;
    }

    public String getDate(){ return date; }

    public String getDay(){
        return day;
    }

    public String getTime(){
        return time;
    }

    public String getTask(){
        return task;
    }

}
