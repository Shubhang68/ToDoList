package com.example.whattodo;

public interface RecyclerViewClickInterface {

    void onItemClick(int position);
    void onItemLongClick(int position);
    void onImgClick(int position);

}
